package com.example.hw7_t;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity_order1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_order1);
    }
}