package com.example.android.simpleasynctask;

import android.os.AsyncTask;

public class mAsyncTest extends AsyncTask {

    

    @Override
    protected Object doInBackground(Object[] objects) {
        return null;
    }
}
